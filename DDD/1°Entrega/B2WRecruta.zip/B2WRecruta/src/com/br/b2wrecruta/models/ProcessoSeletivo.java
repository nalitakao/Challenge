package com.br.b2wrecruta.models;

public class ProcessoSeletivo {
	private int cd_processo_seletivo;
	private int cd_recrutador;
	private String nm_vaga;
	private String ds_area;
	private String ds_status;
	private int nr_max_candidatos;

	public int getCd_processo_seletivo() {
		return cd_processo_seletivo;
	}

	public void setCd_processo_seletivo(int cd_processo_seletivo) {
		this.cd_processo_seletivo = cd_processo_seletivo;
	}

	public int getCd_recrutador() {
		return cd_recrutador;
	}

	public void setCd_recrutador(int cd_recrutador) {
		this.cd_recrutador = cd_recrutador;
	}

	public String getNm_vaga() {
		return nm_vaga;
	}

	public void setNm_vaga(String nm_vaga) {
		this.nm_vaga = nm_vaga;
	}

	public String getDs_area() {
		return ds_area;
	}

	public void setDs_area(String ds_area) {
		this.ds_area = ds_area;
	}

	public String getDs_status() {
		return ds_status;
	}

	public void setDs_status(String ds_status) {
		this.ds_status = ds_status;
	}

	public int getNr_max_candidatos() {
		return nr_max_candidatos;
	}

	public void setNr_max_candidatos(int nr_max_candidatos) {
		this.nr_max_candidatos = nr_max_candidatos;
	}

}
