package com.br.b2wrecruta.models;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class Recrutador {

	private int cd_recrutador;
	private String nm_recrutador;
	private Date dt_nascimento;
	private String nr_cpf_recrutador;
	private String nm_empresa;
	private String nr_cnpj_empresa;
	private String nm_departamento;
	private String ds_cargo;
	private String ds_email;
	private String ds_senha;

	public int getCd_recrutador() {
		return cd_recrutador;
	}

	public void setCd_recrutador(int cd_recrutador) {

		this.cd_recrutador = cd_recrutador;

	}

	public String getNm_recrutador() {
		return nm_recrutador;
	}

	public void setNm_recrutador(String nm_recrutador) {

		if (Pattern.matches("[a-zA-Z]+", nm_recrutador)) {
			this.nm_recrutador = nm_recrutador;
		} else {
			System.out.println("ERRO!");
			System.out.println("Apenas letras no nome do recrutador!");
		}
	}

	public Date getDt_nascimento() {
		return dt_nascimento;
	}

	public void setDt_nascimento(String dt_nascimento) throws ParseException {

		DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		java.sql.Date data = new java.sql.Date(format.parse(dt_nascimento).getTime());

		this.dt_nascimento = data;
	}

	public String getNr_cpf_recrutador() {

		return nr_cpf_recrutador;
	}

	public void setNr_cpf_recrutador(String nr_cpf_recrutador) {

		if (Pattern.matches("^\\d{3}\\d{3}\\d{3}\\d{2}$", nr_cpf_recrutador)) {
			this.nr_cpf_recrutador = nr_cpf_recrutador;
		} else {
			System.out.println("ERRO!");
			System.out.println("Apenas n�meros no CPF!");
			System.out.println("Apenas 11 caracteres permitidos no CPF");
		}

	}

	public String getNm_empresa() {
		return nm_empresa;
	}

	public void setNm_empresa(String nm_empresa) {

		this.nm_empresa = nm_empresa;

	}

	public String getNr_cnpj_empresa() {
		return nr_cnpj_empresa;
	}

	public void setNr_cnpj_empresa(String nr_cnpj_empresa) {

		if (Pattern.matches("^\\d{2}\\d{3}\\d{3}\\d{4}\\d{2}$", nr_cnpj_empresa)) {
			this.nr_cnpj_empresa = nr_cnpj_empresa;
		} else {
			System.out.println("ERRO!");
			System.out.println("Apenas letras no nome do departamento!");
		}

	}

	public String getNm_departamento() {
		return nm_departamento;
	}

	public void setNm_departamento(String nm_departamento) {

		if (Pattern.matches("[a-zA-Z]+", nm_departamento)) {
			this.nm_departamento = nm_departamento;
		} else {
			System.out.println("ERRO!");
			System.out.println("CNPJ inv�lido!");
		}

	}

	public String getDs_cargo() {
		return ds_cargo;
	}

	public void setDs_cargo(String ds_cargo) {
		this.ds_cargo = ds_cargo;
	}

	public String getDs_email() {
		return ds_email;
	}

	public void setDs_email(String ds_email) {

		if (Pattern.matches("/^[a-z0-9.]+@[a-z0-9]+\\.[a-z]+(\\.[a-z]+)?$/i", ds_email)) {
			this.ds_email = ds_email;
		} else {
			System.out.println("ERRO!");
			System.out.println("Email inv�lido!");
		}

	}

	public String getDs_senha() {
		return ds_senha;
	}

	public void setDs_senha(String ds_senha) {

		if (Pattern.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$", ds_senha)) {
			this.ds_senha = ds_senha;
		} else {
			System.out.println("ERRO!");
			System.out.println("Senha deve conter 8 caracteres e no minimo um n�mero e uma letra!");
		}

	}

}
