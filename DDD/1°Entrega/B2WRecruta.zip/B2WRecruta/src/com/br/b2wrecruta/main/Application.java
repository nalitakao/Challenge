package com.br.b2wrecruta.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.br.b2wrecruta.dao.ProcessoSeletivoDAO;
import com.br.b2wrecruta.dao.RecrutadorDAO;
import com.br.b2wrecruta.models.ProcessoSeletivo;
import com.br.b2wrecruta.models.Recrutador;

public class Application {

	public static void main(String[] args) throws SQLException, ParseException {

		ProcessoSeletivoDAO processoDao = new ProcessoSeletivoDAO();
		ProcessoSeletivo processo = new ProcessoSeletivo();
		ProcessoSeletivo testeSelectOne = new ProcessoSeletivo();

		testeSelectOne.setCd_processo_seletivo(1);
		testeSelectOne.setCd_recrutador(1);

		processo.setCd_processo_seletivo(2);
		processo.setCd_recrutador(2);
		processo.setNm_vaga("PROGRAMADOR");
		processo.setDs_area("Area de tecnologia");
		processo.setDs_status("Fechado");
		processo.setNr_max_candidatos(4);

		/*
		 * 
		 * ProcessoSeletivo processo2 = processoDao.selectByID(testeSelectOne);
		 * System.out.print("C�digo do processo: "+processo2.getCd_processo_seletivo());
		 * System.out.print(" | C�digo do recrutador: "+processo2.getCd_recrutador());
		 * System.out.print(" | Nome da vaga: "+processo2.getNm_vaga());
		 * System.out.print(" | �rea: "+processo2.getDs_area());
		 * System.out.print(" | Status da vaga: "+processo2.getDs_status());
		 * System.out.println(" | M�ximo de candidatos: "+processo2.getNr_max_candidatos
		 * ());
		 * 
		 */

		// processoDao.insert(processo);

		// processoDao.update(processo);

		// processoDao.delete(processo);

		/*
		 * List<ProcessoSeletivo> processos = processoDao.selectAll();
		 * 
		 * for(ProcessoSeletivo processo1: processos) {
		 * System.out.print("C�digo do processo: "+processo1.getCd_processo_seletivo());
		 * System.out.print(" | C�digo do recrutador: "+processo1.getCd_recrutador());
		 * System.out.print(" | Nome da vaga: "+processo1.getNm_vaga());
		 * System.out.print(" | �rea: "+processo1.getDs_area());
		 * System.out.print(" | Status da vaga: "+processo1.getDs_status());
		 * System.out.print(" | M�ximo de candidatos: "+processo1.getNr_max_candidatos()
		 * ); }
		 * 
		 */

		RecrutadorDAO recrutadorDao = new RecrutadorDAO();
		Recrutador recrutador1 = new Recrutador();


		/*
		 * List<Recrutador> recrutadores = recrutadorDao.selectAll();
		 * 
		 * 
		 * for(Recrutador recrutador: recrutadores) {
		 * System.out.print("C�digo: "+recrutador.getCd_recrutador());
		 * System.out.print(" | Nome: "+recrutador.getNm_recrutador());
		 * System.out.print(" | Data de nascimento: "+recrutador.getDt_nascimento());
		 * System.out.print(" | CPF: "+recrutador.getNr_cpf_recrutador());
		 * System.out.print(" | Empresa: "+recrutador.getNm_empresa());
		 * System.out.print(" | CNPJ: "+recrutador.getNr_cnpj_empresa());
		 * System.out.print(" | Departamento: "+recrutador.getNm_departamento());
		 * System.out.print(" | Cargo: "+recrutador.getDs_cargo());
		 * System.out.print(" | Email: "+recrutador.getDs_email());
		 * System.out.println(" | Senha: "+recrutador.getDs_senha()); }
		 * 
		 * recrutador1.setCd_recrutador(2); recrutador1.setNm_recrutador("LENNYK");
		 * recrutador1.setDt_nascimento("05-03-2002");
		 * recrutador1.setNr_cpf_recrutador("39372882879");
		 * recrutador1.setNm_empresa("GCB");
		 * recrutador1.setNr_cnpj_empresa("48384939489");
		 * recrutador1.setNm_departamento("Tecnologia");
		 * recrutador1.setDs_cargo("PROGRAMADOR");
		 * recrutador1.setDs_email("hdks@gmail.com");
		 * recrutador1.setDs_senha("SKDKSDKKDKD");
		 * 
		 * recrutadorDao.insert(recrutador1);
		 * 
		 * Recrutador testeGetOne = new Recrutador(); testeGetOne.setCd_recrutador(2);
		 * 
		 * Recrutador recrutador2 = recrutadorDao.selectByID(testeGetOne);
		 * 
		 * System.out.println(recrutador2.getCd_recrutador());
		 * 
		 */

	}
}
