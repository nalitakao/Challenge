package com.br.b2wrecruta.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import com.br.b2wrecruta.factory.ConnectionFactory;
import com.br.b2wrecruta.models.Recrutador;

public class RecrutadorDAO {

	private Connection con;

	public RecrutadorDAO() throws SQLException {
		con = new ConnectionFactory().getConnection();
	}

	public void insert(Recrutador recrutador) throws SQLException {

		PreparedStatement stmt = con.prepareStatement(
				"INSERT INTO t_srs_recrutador(cd_recrutador,nm_recrutador,dt_nascimento,nr_cpf_recrutador,nm_empresa,nr_cnpj_empresa,nm_departamento,ds_cargo,ds_email,ds_senha) VALUES(?,?,?,?,?,?,?,?,?,?)  ");

		try {
			stmt.setInt(1, recrutador.getCd_recrutador());
			stmt.setString(2, recrutador.getNm_recrutador());
			stmt.setDate(3, recrutador.getDt_nascimento());
			stmt.setString(4, recrutador.getNr_cpf_recrutador());
			stmt.setString(5, recrutador.getNm_empresa());
			stmt.setString(6, recrutador.getNr_cnpj_empresa());
			stmt.setString(7, recrutador.getNm_departamento());
			stmt.setString(8, recrutador.getDs_cargo());
			stmt.setString(9, recrutador.getDs_email());
			stmt.setString(10, recrutador.getDs_senha());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("INSERT executado com sucesso!");
			} else {
				System.out.println("INSERT falhou, nenhuma linha foi afetada.");
			}

		} catch (Exception e) {
			System.out.println("Falha na inser��o de dados, tente novamente.");
		}

		stmt.close();

	}

	public void update(Recrutador recrutador) throws SQLException {

		PreparedStatement stmt = con.prepareStatement(
				"UPDATE t_srs_recrutador SET nm_recrutador = ? ,dt_nascimento = ? ,nr_cpf_recrutador = ?,nm_empresa = ?,nr_cnpj_empresa = ?,nm_departamento = ?,ds_cargo = ?,ds_email = ?,ds_senha =? WHERE cd_recrutador = ? ");

		try {
			stmt.setString(1, recrutador.getNm_recrutador());
			stmt.setDate(2, recrutador.getDt_nascimento());
			stmt.setString(3, recrutador.getNr_cpf_recrutador());
			stmt.setString(4, recrutador.getNm_empresa());
			stmt.setString(5, recrutador.getNr_cnpj_empresa());
			stmt.setString(6, recrutador.getNm_departamento());
			stmt.setString(7, recrutador.getDs_cargo());
			stmt.setString(8, recrutador.getDs_email());
			stmt.setString(9, recrutador.getDs_senha());
			stmt.setInt(10, recrutador.getCd_recrutador());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("UPDATE executado com sucesso!");
			} else {
				System.out.println("UPDATE falhou, nenhuma linha foi afetada.");
			}
		} catch (Exception e) {
			System.out.println("Falha no update de dados, tente novamente.");
		}

		stmt.close();

	}

	public void delete(Recrutador recrutador) throws SQLException {

		PreparedStatement stmt = con.prepareStatement("DELETE FROM t_srs_recrutador WHERE cd_recrutador = ?");
		try {

			stmt.setInt(1, recrutador.getCd_recrutador());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("DELETE executado com sucesso!");
			} else {
				System.out.println("DELETE falhou, nenhuma linha foi afetada.");
			}

		} catch (Exception e) {
			System.out.println("Falha na dele��o de dados, tente novamente.");
		}
	}

	public Recrutador selectByID(Recrutador recrutador) throws SQLException, ParseException {
		PreparedStatement stmt = con.prepareStatement("SELECT * FROM t_srs_recrutador WHERE cd_recrutador = ?");
		Recrutador retorno = new Recrutador();

		stmt.setInt(1, recrutador.getCd_recrutador());

		stmt.execute();

		ResultSet result = stmt.getResultSet();
		
		
		result.next();
		retorno.setCd_recrutador(result.getInt("cd_recrutador"));
		retorno.setNm_recrutador(result.getString("nm_recrutador"));
		retorno.setDt_nascimento(result.getString("dt_nascimento"));
		retorno.setNr_cpf_recrutador(result.getString("nr_cpf_recrutador"));
		retorno.setNm_empresa(result.getString("nm_empresa"));
		retorno.setNr_cnpj_empresa(result.getString("nr_cnpj_empresa"));
		retorno.setNm_departamento(result.getString("nm_departamento"));
		retorno.setDs_cargo(result.getString("ds_cargo"));
		retorno.setDs_email(result.getString("ds_email"));
		retorno.setDs_senha(result.getString("ds_senha"));

		
		
		return retorno;

	}

	public List<Recrutador> selectAll() throws SQLException, ParseException {

		PreparedStatement stmt = con.prepareStatement("SELECT * FROM t_srs_recrutador");
		ArrayList<Recrutador> recrutadores = new ArrayList<Recrutador>();

		stmt.execute();

		ResultSet result = stmt.getResultSet();

		while (result.next()) {
			Recrutador recrutador = new Recrutador();
			recrutador.setCd_recrutador(result.getInt("cd_recrutador"));
			recrutador.setNm_recrutador(result.getString("nm_recrutador"));
			recrutador.setDt_nascimento(result.getString("dt_nascimento"));
			recrutador.setNr_cpf_recrutador(result.getString("nr_cpf_recrutador"));
			recrutador.setNm_empresa(result.getString("nm_empresa"));
			recrutador.setNr_cnpj_empresa(result.getString("nr_cnpj_empresa"));
			recrutador.setNm_departamento(result.getString("nm_departamento"));
			recrutador.setDs_cargo(result.getString("ds_cargo"));
			recrutador.setDs_email(result.getString("ds_email"));
			recrutador.setDs_senha(result.getString("ds_senha"));

			recrutadores.add(recrutador);

		}

		return recrutadores;

	}

}
