package com.br.b2wrecruta.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.br.b2wrecruta.factory.ConnectionFactory;
import com.br.b2wrecruta.models.ProcessoSeletivo;
import com.br.b2wrecruta.models.Recrutador;

public class ProcessoSeletivoDAO {

	private Connection con;

	public ProcessoSeletivoDAO() throws SQLException {

		con = new ConnectionFactory().getConnection();
	}

	public void insert(ProcessoSeletivo processo) throws SQLException {

		PreparedStatement stmt = con.prepareStatement(
				"INSERT INTO t_srs_processo_seletivo(cd_processo_seletivo,cd_recrutador,nm_vaga,ds_area,ds_status,nr_max_candidatos) VALUES(?,?,?,?,?,?)  ");

		try {
			stmt.setInt(1, processo.getCd_processo_seletivo());
			stmt.setInt(2, processo.getCd_recrutador());
			stmt.setString(3, processo.getNm_vaga());
			stmt.setString(4, processo.getDs_area());
			stmt.setString(5, processo.getDs_status());
			stmt.setInt(6, processo.getNr_max_candidatos());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("INSERT executado com sucesso!");
			} else {
				System.out.println("INSERT falhou, nenhuma linha foi afetada.");
			}

		} catch (Exception e) {
			System.out.println(
					"Falha na inser��o de dados, verifique se o c�digo de recrutador existe e tente novamente.");
		}

		stmt.close();

	}

	public void update(ProcessoSeletivo processo) throws SQLException {

		PreparedStatement stmt = con.prepareStatement(
				"UPDATE t_srs_processo_seletivo SET cd_recrutador = ? ,nm_vaga = ?,ds_area = ?,ds_status = ?,nr_max_candidatos = ? WHERE cd_processo_seletivo = ? ");

		try {
			stmt.setInt(6, processo.getCd_processo_seletivo());
			stmt.setInt(1, processo.getCd_recrutador());
			stmt.setString(2, processo.getNm_vaga());
			stmt.setString(3, processo.getDs_area());
			stmt.setString(4, processo.getDs_status());
			stmt.setInt(5, processo.getNr_max_candidatos());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("UPDATE executado com sucesso!");
			} else {
				System.out.println("UPDATE falhou, nenhuma linha foi afetada.");
			}
		} catch (Exception e) {
			System.out.println("Falha no update de dados, tente novamente.");
		}

		stmt.close();

	}

	public void delete(ProcessoSeletivo processo) throws SQLException {

		PreparedStatement stmt = con
				.prepareStatement("DELETE FROM t_srs_processo_seletivo WHERE cd_processo_seletivo = ?");
		try {

			stmt.setInt(1, processo.getCd_processo_seletivo());

			stmt.execute();

			if (stmt.getUpdateCount() > 0) {
				System.out.println("DELETE executado com sucesso!");
			} else {
				System.out.println("DELETE falhou, nenhuma linha foi afetada.");
			}

		} catch (Exception e) {
			System.out.println("Falha na dele��o de dados, tente novamente.");
		}
	}

	public ProcessoSeletivo selectByID(ProcessoSeletivo processo) throws SQLException {
		PreparedStatement stmt = con
				.prepareStatement("SELECT * FROM t_srs_processo_seletivo WHERE cd_processo_seletivo = ?");
		ProcessoSeletivo retorno = new ProcessoSeletivo();

		stmt.setInt(1, processo.getCd_processo_seletivo());

		stmt.execute();

		ResultSet result = stmt.getResultSet();

		result.next();
		retorno.setCd_processo_seletivo((result.getInt("cd_processo_seletivo")));
		retorno.setCd_recrutador(result.getInt("cd_recrutador"));
		retorno.setNm_vaga(result.getString("nm_vaga"));
		retorno.setDs_area(result.getString("ds_area"));
		retorno.setDs_status(result.getString("ds_status"));
		retorno.setNr_max_candidatos(result.getInt("nr_max_candidatos"));

		return retorno;

	}
	
	
	public List<ProcessoSeletivo> selectAll() throws SQLException{

		PreparedStatement stmt = con.prepareStatement("SELECT * FROM t_srs_processo_seletivo");
		ArrayList<ProcessoSeletivo> processos = new ArrayList<ProcessoSeletivo>();

		stmt.execute();

		ResultSet result = stmt.getResultSet();

		while (result.next()) {
			ProcessoSeletivo processo = new ProcessoSeletivo();
			Recrutador recrutador = new Recrutador();
			processo.setCd_processo_seletivo(result.getInt("cd_processo_seletivo"));
			processo.setCd_recrutador(result.getInt("cd_recrutador"));
			processo.setNm_vaga(result.getString("nm_vaga"));
			processo.setDs_area(result.getString("ds_area"));
			processo.setDs_status(result.getString("ds_status"));
			processo.setNr_max_candidatos(result.getInt("nr_max_candidatos"));
			recrutador.setNm_recrutador(result.getString("nm_recrutador"));
			

			processos.add(processo);

		}

		return processos;

	}
	
}
